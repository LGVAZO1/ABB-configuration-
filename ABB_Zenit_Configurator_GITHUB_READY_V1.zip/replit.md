# ABB Zenit Configurator

Mobile-first web configurator for assembling ABB Zenit modular wall mechanisms into physically valid kits.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/abb-zenit-configurator/src/data/products.json` — local starter catalogue; replace with the authoritative product export when supplied.
- `artifacts/abb-zenit-configurator/src/data/mappings.ts` — layout, frame, and mounting-plate mappings from the brief.
- `artifacts/abb-zenit-configurator/src/engine/` — database validation, deterministic placement, and kit generation.
- `artifacts/abb-zenit-configurator/src/App.tsx` — mobile-first configurator UI.

## Architecture decisions

- Physical width and independent functions remain separate product fields.
- Placement uses deterministic descending-width backtracking across independent physical zones; total-width checks are not used.
- Frame and mounting plate articles are selected from mapping tables and are never fabricated when absent.
- The client can import JSON or CSV catalogue exports; imported data is validated before it becomes active.

## Product

Sales consultants can choose finish and frame layout, search and add mechanisms, inspect physical zone placement, and generate a validated bill of materials with automatic frame and mounting plate components.

## User preferences

No saved preferences.

## Gotchas

- The attached brief did not include the authoritative catalogue. The starter dataset only uses article numbers and codes explicitly present in the brief; it is not a substitute for the real product export.
- The 2+2M, 2+2+2M, and 2+2+2+2M layouts are independent 2M zones, not one combined capacity.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
