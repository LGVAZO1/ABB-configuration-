# ABB Zenit Configurator — GitHub/Codespaces

This repository contains the ABB Zenit configurator with the corrected configuration logic and master database.

## Run in GitHub Codespaces

```bash
pnpm install
pnpm --filter @workspace/abb-zenit-configurator run dev -- --host 0.0.0.0
```

Open the forwarded Vite port in the browser.

## Notes

- Use pnpm, not npm.
- The project is a pnpm workspace.
- The `database/` directory contains the master Excel database used for the corrected runtime data.
