import type {
  BuildResult,
  ConfiguratorMappings,
  LayoutDefinition,
  LayoutId,
  Product,
  SelectedProduct,
  UserColor,
  KitItem,
  PlacementZone,
} from '../data/types';
import { placeProducts } from './placement';

interface ConfiguratorOptions {
  products: Product[];
  layouts: LayoutDefinition[];
  mappings: ConfiguratorMappings;
}

export class ZenitConfigurator {
  private readonly products: Product[];
  private readonly layouts: LayoutDefinition[];
  private readonly mappings: ConfiguratorMappings;
  private color: UserColor = 'AN';
  private layout: LayoutId = '2M';
  private selected = new Map<string, number>();

  constructor(options: ConfiguratorOptions) {
    this.products = options.products;
    this.layouts = options.layouts;
    this.mappings = options.mappings;
  }

  setColor(color: UserColor): void {
    this.color = color;
  }

  setLayout(layout: LayoutId): void {
    this.layout = layout;
  }

  addProduct(article: string): void {
    const product = this.products.find((item) => item.article === article);
    if (!product) throw new Error(`Product article does not exist in database: ${article}`);
    this.selected.set(article, (this.selected.get(article) ?? 0) + 1);
  }

  removeProduct(article: string): void {
    const current = this.selected.get(article) ?? 0;
    if (current <= 1) this.selected.delete(article);
    else this.selected.set(article, current - 1);
  }

  clearProducts(): void {
    this.selected.clear();
  }

  getSelectedProducts(): SelectedProduct[] {
    return [...this.selected.entries()]
      .map(([article, quantity]) => {
        const product = this.products.find((item) => item.article === article);
        return product ? { product, quantity } : null;
      })
      .filter((entry): entry is SelectedProduct => entry !== null);
  }

  build(): BuildResult {
    const selected = this.getSelectedProducts();
    const definition = this.layouts.find((item) => item.id === this.layout);
    const emptyZones = this.getEmptyZones(definition);
    const base = {
      color: this.color,
      layout: this.layout,
      zones: emptyZones,
      kit: [] as KitItem[],
      warnings: [] as string[],
    };

    if (!selected.length) {
      return {
        ...base,
        success: false,
        errorCode: 'NO_PRODUCT_SELECTED',
        message: 'No mechanism selected. Add at least one mechanism to continue.',
      };
    }
    if (!definition) {
      return {
        ...base,
        success: false,
        errorCode: 'NO_VALID_PLACEMENT',
        message: 'Selected layout does not exist in the layout table.',
      };
    }

    const expanded: Product[] = [];
    for (const { product, quantity } of selected) {
      if (!product.useInZenitWallConfigurator) {
        return {
          ...base,
          success: false,
          errorCode: 'PRODUCT_NOT_ENABLED',
          message: `${product.article} is not enabled for the Zenit wall configurator.`,
        };
      }
      if (product.color !== this.color && product.color !== 'NEUTRAL') {
        return {
          ...base,
          success: false,
          errorCode: 'COLOR_MISMATCH',
          message: `Selected product color does not match ${this.color}.`,
        };
      }
      if (!product.isMechanism || product.componentRole !== 'mechanism') {
        return { ...base, success: false, errorCode: 'PRODUCT_NOT_ENABLED', message: `${product.article} is not a selectable mechanism.` };
      }
      if (!Number.isInteger(product.width) || product.width <= 0) {
        return {
          ...base,
          success: false,
          errorCode: 'INVALID_PRODUCT_DATA',
          message: `${product.article} has invalid physical width data.`,
        };
      }
      for (let index = 0; index < quantity; index += 1) expanded.push(product);
    }

    const zones = placeProducts(expanded, definition.zones);
    if (!zones) {
      const widest = Math.max(...expanded.map((product) => product.width));
      const largestZone = Math.max(...definition.zones);
      const specific =
        widest > largestZone
          ? `${widest}M mechanism cannot fit into ${this.layout}.`
          : 'Selected mechanisms cannot physically fit into this layout.';
      return {
        ...base,
        success: false,
        errorCode: 'NO_VALID_PLACEMENT',
        message: specific,
      };
    }

    const kit = this.aggregateMechanisms(selected);
    const mappingWarnings: string[] = [];

    // Required data-outlet covers: the ABB 2018.6 RJ45 mechanism needs its matching cover.
    for (const { product, quantity } of selected) {
      if (product.abbFamilyCode === 'CLA201860') {
        const coverCode = this.color === 'AN' ? '2CLA211810N1801' : '2CLA211810N1101';
        const cover = this.products.find((item) => item.abbCode === coverCode);
        if (cover) kit.push(this.toKitItem(cover, 'accessory', quantity));
        else mappingWarnings.push(`Required RJ45 cover ${coverCode} is missing from the database.`);
      }
    }
    const plateArticle = this.mappings.mountingPlates[this.layout];
    if (!plateArticle) {
      mappingWarnings.push('Mounting plate mapping is not configured for this layout.');
    } else {
      const plate = this.products.find((product) => product.article === plateArticle);
      if (!plate) {
        return {
          ...base,
          success: false,
          errorCode: 'MOUNTING_PLATE_MAPPING_MISSING',
          message: `Mounting plate article ${plateArticle} does not exist in the database.`,
        };
      }
      const plateQty = this.layout === '2+2+2+2M' ? 2 : 1;
      kit.push(this.toKitItem(plate, 'mounting_plate', plateQty));
    }

    const frameArticle = this.mappings.frames[this.color][this.layout];
    if (!frameArticle) {
      return {
        ...base,
        success: false,
        errorCode: 'FRAME_MAPPING_MISSING',
        message: 'Frame mapping is missing for the selected color and layout.',
      };
    }
    const frame = this.products.find((product) => product.article === frameArticle);
    if (!frame) {
      return {
        ...base,
        success: false,
        errorCode: 'FRAME_MAPPING_MISSING',
        message: `Frame article ${frameArticle} does not exist in the database.`,
      };
    }
    kit.push(this.toKitItem(frame, 'frame'));

    return {
      success: true,
      color: this.color,
      layout: this.layout,
      zones,
      kit,
      warnings: mappingWarnings,
    };
  }

  private aggregateMechanisms(selected: SelectedProduct[]): KitItem[] {
    return selected.map(({ product, quantity }) => ({
      ...this.toKitItem(product, 'mechanism'),
      quantity,
    }));
  }

  private toKitItem(product: Product, role: KitItem['role'], quantity = 1): KitItem {
    return {
      article: product.article,
      name: product.name,
      abbCode: product.abbCode,
      quantity,
      role,
      physicalWidth: product.width,
    };
  }

  private getEmptyZones(definition?: LayoutDefinition): PlacementZone[] {
    return (definition?.zones ?? []).map((capacity, index) => ({
      id: index + 1,
      capacity,
      used: 0,
      remaining: capacity,
      products: [],
    }));
  }
}