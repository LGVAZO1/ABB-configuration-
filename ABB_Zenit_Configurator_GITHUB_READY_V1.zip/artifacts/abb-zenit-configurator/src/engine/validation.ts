import type {
  ConfiguratorMappings,
  LayoutDefinition,
  Product,
  ValidationReport,
} from '../data/types';

const colors = new Set(['AN', 'BL', 'NEUTRAL']);

export function validateDatabase(
  products: Product[],
  layouts: LayoutDefinition[],
  mappings: ConfiguratorMappings,
): ValidationReport {
  const errors: string[] = [];
  const warnings: string[] = [];
  const articles = new Set<string>();
  const layoutIds = new Set(layouts.map((layout) => layout.id));

  for (const product of products) {
    if (!product.article?.trim()) errors.push('Product is missing an article.');
    if (product.article && articles.has(product.article)) {
      errors.push(`Duplicate product article: ${product.article}`);
    }
    articles.add(product.article);
    if (!product.name?.trim()) errors.push(`Missing name for ${product.article || 'unknown product'}.`);
    if (!Number.isInteger(product.width) || product.width <= 0) {
      errors.push(`Invalid width for ${product.article || 'unknown product'}.`);
    }
    if (!Number.isInteger(product.functions) || product.functions < 0) {
      errors.push(`Invalid functions value for ${product.article || 'unknown product'}.`);
    }
    if (!colors.has(product.color)) errors.push(`Invalid color for ${product.article}.`);
    if (!product.type?.trim()) errors.push(`Missing type for ${product.article}.`);
    if (product.layout && !layoutIds.has(product.layout as LayoutDefinition['id']) && product.type !== 'switch') {
      warnings.push(`Unrecognized layout "${product.layout}" on ${product.article}.`);
    }
    if (product.useInZenitWallConfigurator && product.color === 'NEUTRAL') {
      warnings.push(`${product.article} is enabled for the wall configurator but is neutral.`);
    }
    if (product.useInZenitWallConfigurator && (!product.variant || !product.width)) {
      errors.push(`Wall-configurator product ${product.article} is missing required information.`);
    }
  }

  for (const layout of layouts) {
    const plateArticle = mappings.mountingPlates[layout.id];
    if (!plateArticle) {
      warnings.push(`Mounting plate mapping is not configured for ${layout.id}.`);
    } else if (!articles.has(plateArticle)) {
      errors.push(`Mounting plate article ${plateArticle} for ${layout.id} does not exist in database.`);
    }
    for (const color of ['AN', 'BL'] as const) {
      const frameArticle = mappings.frames[color][layout.id];
      if (!frameArticle) {
        errors.push(`Frame mapping is missing for ${color} + ${layout.id}.`);
      } else if (!articles.has(frameArticle)) {
        errors.push(`Frame article ${frameArticle} for ${color} + ${layout.id} does not exist in database.`);
      }
    }
  }

  return { valid: errors.length === 0, errors, warnings };
}