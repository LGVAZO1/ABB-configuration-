import type { PlacementZone, Product } from '../data/types';

interface SearchZone {
  id: number;
  capacity: number;
  products: Product[];
}

function orderZones(zones: SearchZone[], product: Product): SearchZone[] {
  return [...zones].sort((a, b) => {
    const aRemaining = a.capacity - a.products.reduce((sum, item) => sum + item.width, 0);
    const bRemaining = b.capacity - b.products.reduce((sum, item) => sum + item.width, 0);
    const aExact = aRemaining === product.width ? 0 : 1;
    const bExact = bRemaining === product.width ? 0 : 1;
    return aExact - bExact || aRemaining - bRemaining || a.id - b.id;
  });
}

function search(products: Product[], zones: SearchZone[], index = 0): SearchZone[] | null {
  if (index >= products.length) return zones;

  const product = products[index];
  for (const candidate of orderZones(zones, product)) {
    const used = candidate.products.reduce((sum, item) => sum + item.width, 0);
    if (used + product.width > candidate.capacity) continue;

    const nextZones = zones.map((zone) =>
      zone.id === candidate.id
        ? { ...zone, products: [...zone.products, product] }
        : { ...zone, products: [...zone.products] },
    );
    const result = search(products, nextZones, index + 1);
    if (result) return result;
  }
  return null;
}

export function placeProducts(products: Product[], capacities: number[]): PlacementZone[] | null {
  const ordered = [...products].sort(
    (a, b) => b.width - a.width || a.article.localeCompare(b.article),
  );
  const zones = capacities.map((capacity, index) => ({ id: index + 1, capacity, products: [] }));
  const placed = search(ordered, zones);
  if (!placed) return null;

  return placed.map((zone) => {
    const used = zone.products.reduce((sum, product) => sum + product.width, 0);
    return {
      id: zone.id,
      capacity: zone.capacity,
      used,
      remaining: zone.capacity - used,
      products: zone.products,
    };
  });
}