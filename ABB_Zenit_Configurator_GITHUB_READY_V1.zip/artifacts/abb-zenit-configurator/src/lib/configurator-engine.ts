import {
  ACCESSORIES,
  LAYOUTS,
  PRODUCTS,
  type Finish,
  type LayoutId,
  type Mechanism,
} from '@/data/zenit-catalog';
import { mappings } from '@/data/mappings';
import type { BuildResult, KitItem, Product } from '@/data/types';
import { ZenitConfigurator } from '@/engine/configurator';
import { validateDatabase } from '@/engine/validation';

export type SelectedMechanism = Mechanism & { quantity: number };
export type Placement = SelectedMechanism & { zone: number; start: number; end: number };

export type ConfigurationResult = {
  layout: LayoutId;
  finish: Finish;
  selected: SelectedMechanism[];
  placements: Placement[];
  errors: string[];
  usedSlots: number;
  totalSlots: number;
  isValid: boolean;
  build: BuildResult;
  kit: KitItem[];
};

function makeConfigurator(layout: LayoutId, finish: Finish, selected: SelectedMechanism[]) {
  const configurator = new ZenitConfigurator({
    products: PRODUCTS,
    layouts: LAYOUTS,
    mappings,
  });
  configurator.setColor(finish);
  configurator.setLayout(layout);
  for (const item of selected) {
    for (let index = 0; index < item.quantity; index += 1) {
      configurator.addProduct(item.article);
    }
  }
  return configurator;
}

function createPlacements(selected: SelectedMechanism[], build: BuildResult): Placement[] {
  if (!build.success) return [];
  const counts = new Map<string, number>();
  const placements: Placement[] = [];
  for (const zone of build.zones) {
    let cursor = 0;
    for (const product of zone.products) {
      const occurrence = (counts.get(product.article) ?? 0) + 1;
      counts.set(product.article, occurrence);
      const selectedItem = selected.find((item) => item.article === product.article);
      if (!selectedItem) continue;
      placements.push({
        ...selectedItem,
        quantity: 1,
        zone: zone.id,
        start: cursor + 1,
        end: cursor + product.width,
        id: `${product.article}-${occurrence}`,
      });
      cursor += product.width;
    }
  }
  return placements;
}

export function calculateConfiguration(
  layout: LayoutId,
  finish: Finish,
  selected: SelectedMechanism[],
): ConfigurationResult {
  const configurator = makeConfigurator(layout, finish, selected);
  const build = configurator.build();
  const placements = createPlacements(selected, build);
  const layoutData = LAYOUTS.find((item) => item.id === layout) ?? LAYOUTS[0];
  const usedSlots = build.zones.reduce((sum, zone) => sum + zone.used, 0);
  return {
    layout,
    finish,
    selected,
    placements,
    errors: build.success ? [] : [build.message],
    usedSlots,
    totalSlots: layoutData.zones.reduce((sum, value) => sum + value, 0),
    isValid: build.success,
    build,
    kit: build.success ? build.kit : [],
  };
}

export function accessoryBom(layout: LayoutId, finish: Finish) {
  const result = calculateConfiguration(layout, finish, []);
  if (result.build.success) {
    return result.kit
      .filter((item) => item.role !== 'mechanism')
      .map((item) => ({
        article: item.article,
        name: item.name,
        variant: layout,
        kind: 'Automatic',
      }));
  }

  const plate = ACCESSORIES.plate[layout];
  const frameArticle = mappings.frames[finish][layout];
  const frame = PRODUCTS.find((product) => product.article === frameArticle);
  return [
    ...(mappings.mountingPlates[layout]
      ? [{ ...plate, kind: 'Automatic' }]
      : []),
    ...(frame
      ? [{ article: frame.article, name: frame.name, variant: layout, kind: 'Automatic' }]
      : []),
  ];
}

export function catalogHealth() {
  const report = validateDatabase(PRODUCTS, LAYOUTS, mappings);
  return {
    records: PRODUCTS.length,
    duplicates: report.errors.filter((item) => item.toLowerCase().includes('duplicate')).length,
    status: report.valid ? 'validated' : 'attention',
    errors: report.errors,
    warnings: report.warnings,
  } as const;
}