import { type ReactNode, useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle,
  Check,
  ClipboardList,
  Database,
  FileUp,
  Minus,
  Plus,
  RotateCcw,
  Search,
  SlidersHorizontal,
  X,
  Zap,
} from 'lucide-react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import {
  ფერიES,
  getCategoryLabels,
  getMechanisms,
  LAYOUTS,
  setProductCatalog,
  type Finish,
  type LayoutId,
  type Mechanism,
  type MechanismCategory,
} from '@/data/zenit-catalog';
import { parseCatalogFile } from '@/data/import-catalog';
import {
  accessoryBom,
  calculateConfiguration,
  catalogHealth,
  type SelectedMechanism,
} from '@/lib/configurator-engine';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';

const queryClient = new QueryClient();
const DEBUG = new URLSearchParams(window.location.search).get('debug') === 'true';

function SectionHeading({
  number,
  eyebrow,
  title,
  action,
}: {
  number: string;
  eyebrow: string;
  title: string;
  action?: ReactNode;
}) {
  return (
    <div className="flex ერთეულიs-start justify-between gap-4">
      <div className="flex gap-3">
        <div className="mono mt-0.5 text-[11px] font-medium text-[#a0a39f]">{number}</div>
        <div>
          <div className="eyebrow">{eyebrow}</div>
          <h2 className="mt-1 text-[19px] font-extrabold tracking-[-.035em] text-[#272d30]">{title}</h2>
        </div>
      </div>
      {action}
    </div>
  );
}

function AppHeader({
  status,
  onგასუფთავება,
  onიმპორტი,
}: {
  status: 'loading' | 'validated';
  onგასუფთავება: () => void;
  onიმპორტი: (file: File) => void;
}) {
  return (
    <header className="border-b border-[#ddd9d1] bg-[#f7f7f7]/90 backdrop-blur">
      <div className="mx-auto flex min-h-[67px] max-w-[1440px] ერთეულიs-center justify-between gap-4 px-4 py-3 sm:px-6 lg:px-10">
        <div className="flex min-w-0 ერთეულიs-center gap-3">
          <div className="brand-mark shrink-0">ABB</div>
          <div className="min-w-0">
            <div className="flex ერთეულიs-center gap-2">
              <span className="truncate text-[15px] font-extrabold tracking-[-.035em] text-[#1a1a1a]">Zenit / კონფიგურატორი</span>
              <span className="hidden rounded-full border border-[#dedad2] bg-[#f0eee9] px-2 py-0.5 text-[9px] font-bold uppercase tracking-[.12em] text-[#777d7d] sm:inline">სამუშაო ინსტრუმენტი</span>
            </div>
            <div className="mono mt-0.5 text-[10px] text-[#8b908f]">მოდულური ელექტრო აქსესუარები · v1.0</div>
          </div>
        </div>
        <div className="flex ერთეულიs-center gap-2">
          <div className="hidden ერთეულიs-center gap-2 rounded-full border border-[#dedbd4] bg-[#fdfcf9] px-3 py-2 sm:flex">
            <span className={`h-2 w-2 rounded-full ${status === 'loading' ? 'animate-pulse bg-[#dba52e]' : 'bg-[#3c9b6c]'}`} />
            <span className="mono text-[10px] uppercase tracking-[.08em] text-[#6c7372]">
              {status === 'loading' ? 'მონაცემთა ბაზის შემოწმება' : 'მონაცემთა ბაზა დადასტურებულია'}
            </span>
          </div>
          <button
            type="button"
            data-testid="button-reset-configuration"
            onClick={onგასუფთავება}
            className="focus-ring flex min-h-10 ერთეულიs-center gap-2 rounded-lg border border-[#d8d4cc] bg-[#fdfcf9] px-3 text-[12px] font-bold text-[#555c5d] transition-colors hover:bg-[#efede7] active:bg-[#e7e4de]"
          >
            <RotateCcw size={14} strokeWidth={2.2} />
            <span className="hidden sm:inline">გასუფთავება</span>
          </button>
          <label className="focus-ring flex min-h-10 cursor-pointer ერთეულიs-center gap-2 rounded-lg border border-[#d8d4cc] bg-[#fdfcf9] px-3 text-[12px] font-bold text-[#555c5d] transition-colors hover:bg-[#efede7]">
            <FileUp size={14} strokeWidth={2.2} />
            <span className="hidden sm:inline">იმპორტი</span>
            <input
              type="file"
              accept=".json,.csv,.txt"
              className="sr-only"
              onChange={(event) => {
                const file = event.target.files?.[0];
                if (file) onიმპორტი(file);
                event.target.value = '';
              }}
            />
          </label>
        </div>
      </div>
    </header>
  );
}

function FinishControl({ finish, setFinish }: { finish: Finish; setFinish: (value: Finish) => void }) {
  return (
    <div>
      <div className="mb-2 flex ერთეულიs-baseline justify-between">
        <label className="eyebrow" htmlFor="finish-anthracite">ფერი</label>
        <span className="mono text-[10px] text-[#9b9d98]">01 / 02</span>
      </div>
      <div className="grid grid-cols-2 gap-2">
        {ფერიES.map((ერთეული) => {
          const selected = finish === ერთეული.id;
          return (
            <button
              type="button"
              id={ერთეული.id === 'AN' ? 'finish-anthracite' : 'finish-white'}
              key={ერთეული.id}
              data-testid={`button-finish-${ერთეული.id.toLowerCase()}`}
              onClick={() => setFinish(ერთეული.id)}
              className={`focus-ring relative flex min-h-[64px] ერთეულიs-center gap-3 rounded-[10px] border px-3 text-left transition-all ${selected ? 'border-[#ff0000] bg-[#fff9f5] shadow-[0_0_0_2px_rgba(213,47,36,.1)]' : 'border-[#dcd9d2] bg-[#fdfcf9] hover:border-[#b8b7b1]'}`}
              aria-pressed={selected}
            >
              <span className="h-7 w-7 shrink-0 rounded-full border border-black/10 shadow-inner" style={{ backgroundColor: ერთეული.swatch }} />
              <span>
                <span className="block text-[13px] font-extrabold text-[#303639]">{ერთეული.longLabel}</span>
                <span className="mono mt-0.5 block text-[10px] text-[#898d8b]">{ერთეული.label} · {ერთეული.id === 'AN' ? 'deep graphite' : 'soft white'}</span>
              </span>
              {selected && <Check size={15} className="absolute right-3 top-3 text-[#ff0000]" strokeWidth={2.8} />}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function LayoutControl({ layout, setLayout }: { layout: LayoutId; setLayout: (value: LayoutId) => void }) {
  return (
    <div>
      <div className="mb-2 flex ერთეულიs-baseline justify-between">
        <label className="eyebrow" htmlFor="layout-select">ჩარჩო / განლაგება</label>
        <span className="mono text-[10px] text-[#9b9d98]">02 / 02</span>
      </div>
      <div className="grid grid-cols-5 gap-1.5">
        {LAYOUTS.map((ერთეული) => {
          const selected = layout === ერთეული.id;
          return (
            <button
              type="button"
              key={ერთეული.id}
              data-testid={`button-layout-${ერთეული.id.replaceAll('+', '-')}`}
              onClick={() => setLayout(ერთეული.id)}
              className={`focus-ring flex min-h-[57px] flex-col ერთეულიs-center justify-center rounded-[9px] border px-1 py-2 transition-all ${selected ? 'border-[#31383a] bg-[#31383a] text-[#faf8f2]' : 'border-[#dcd9d2] bg-[#fdfcf9] text-[#475052] hover:border-[#a8aaa5]'}`}
              aria-pressed={selected}
            >
              <span className="mono text-[12px] font-medium">{ერთეული.label}</span>
              <span className={`mt-1 text-[9px] ${selected ? 'text-[#ccd0cc]' : 'text-[#929692]'}`}>{ერთეული.caption}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

function ZoneDiagram({
  layout,
  finish,
  placements,
}: {
  layout: LayoutId;
  finish: Finish;
  placements: ReturnType<typeof calculateConfiguration>['placements'];
}) {
  const layoutData = LAYOUTS.find((ერთეული) => ერთეული.id === layout) ?? LAYOUTS[0];
  return (
    <div className="technical-grid rounded-[12px] border border-[#e4e0d8] bg-[#f6f4ef] p-3 sm:p-4">
      <div className="mb-3 flex ერთეულიs-center justify-between">
        <span className="eyebrow">ფიზიკური განლაგება</span>
        <span className="mono text-[10px] text-[#949994]">წინა ხედი · მასშტაბი პირობითია</span>
      </div>
      <div className="flex min-h-[128px] ერთეულიs-center justify-center gap-2 overflow-x-auto rounded-lg border border-[#d4d1c9] bg-[#e4e2dc] px-3 py-5 shadow-inner">
        {layoutData.zones.map((capacity, zoneIndex) => (
          <div
            key={`${layout}-${zoneIndex}`}
            data-testid={`zone-${zoneIndex + 1}`}
            className={`relative flex min-w-[78px] flex-1 flex-col gap-1.5 rounded-[9px] border-2 p-2 transition-colors sm:min-w-[94px] ${finish === 'AN' ? 'border-[#596063] bg-[#32383b]' : 'border-[#bfc0bd] bg-[#f8f7f3]'}`}
          >
            <div className={`mono flex ერთეულიs-center justify-between text-[9px] ${finish === 'AN' ? 'text-[#aeb6b7]' : 'text-[#737978]'}`}>
              <span>ZONE {String(zoneIndex + 1).padStart(2, '0')}</span>
              <span>{capacity}M</span>
            </div>
            <div className="flex min-h-[58px] flex-1 gap-1">
              {Array.from({ length: capacity }).map((_, slotIndex) => {
                const placement = placements.find((ერთეული) => ერთეული.zone === zoneIndex + 1 && ერთეული.start <= slotIndex + 1 && ერთეული.end >= slotIndex + 1);
                const isStart = placement?.start === slotIndex + 1;
                return (
                  <div
                    key={slotIndex}
                    className={`relative min-w-0 flex-1 rounded-md border ${finish === 'AN' ? 'border-[#60696a] bg-[#434b4e]' : 'border-[#d6d4ce] bg-[#eeece6]'}`}
                  >
                    {placement && isStart && (
                      <div className={`pop-in absolute inset-0 z-10 flex ერთეულიs-center justify-center overflow-hidden rounded-md px-1 text-center ${finish === 'AN' ? 'bg-[#566063] text-[#fbfaf5]' : 'bg-[#d9d7d0] text-[#343b3c]'}`}>
                        <span className="line-clamp-3 text-[8px] font-extrabold leading-[1.1]">{placement.name}</span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
      <div className="mt-3 flex flex-wrap ერთეულიs-center gap-x-4 gap-y-1.5 text-[10px] text-[#777c79]">
        <span className="flex ერთეულიs-center gap-1.5"><span className="h-2 w-2 rounded-sm bg-[#ff0000]" /> მექანიზმის პოზიცია</span>
        <span className="flex ერთეულიs-center gap-1.5"><span className="h-2 w-2 rounded-sm border border-[#9da19d] bg-transparent" /> თავისუფალი მოდულის ადგილი</span>
      </div>
    </div>
  );
}

function Summary({
  layout,
  finish,
  result,
  onRemove,
  onIncrement,
  onDecrement,
}: {
  layout: LayoutId;
  finish: Finish;
  result: ReturnType<typeof calculateConfiguration>;
  onRemove: (id: string) => void;
  onIncrement: (id: string) => void;
  onDecrement: (id: string) => void;
}) {
  const count = result.selected.reduce((sum, ერთეული) => sum + ერთეული.quantity, 0);
  return (
    <aside className="summary-sticky panel overflow-hidden">
      <div className="border-b border-[#e5e1da] bg-[#fdfcf9] px-4 py-4 sm:px-5">
        <div className="flex ერთეულიs-center justify-between">
          <div>
            <div className="eyebrow">მიმდინარე კონფიგურაცია</div>
            <h2 className="mt-1 text-[18px] font-extrabold tracking-[-.04em] text-[#292f31]">Zenit-ის კომპლექტი</h2>
          </div>
          <div className="flex h-10 w-10 ერთეულიs-center justify-center rounded-full bg-[#f2e6df] text-[#ff0000]">
            <ClipboardList size={18} strokeWidth={2.1} />
          </div>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-2">
          <div className="rounded-lg border border-[#e0dcd5] bg-[#f5f3ee] p-2.5">
            <div className="eyebrow">ჩარჩო</div>
            <div className="mono mt-1 text-[14px] font-medium text-[#303739]">{layout}</div>
          </div>
          <div className="rounded-lg border border-[#e0dcd5] bg-[#f5f3ee] p-2.5">
            <div className="eyebrow">ფერი</div>
            <div className="mono mt-1 text-[14px] font-medium text-[#303739]">{finish}</div>
          </div>
        </div>
      </div>
      <div className="px-4 py-4 sm:px-5">
        <div className="mb-2 flex ერთეულიs-center justify-between">
          <span className="eyebrow">არჩეული მექანიზმები</span>
          <span className="mono text-[10px] text-[#8a8e8b]">{count} {count === 1 ? 'ერთეული' : 'ერთეულიs'}</span>
        </div>
        {result.selected.length === 0 ? (
          <div data-testid="empty-selection" className="rounded-lg border border-dashed border-[#d4d0c7] bg-[#f7f5f0] px-3 py-5 text-center">
            <SlidersHorizontal size={19} className="mx-auto text-[#a4a7a1]" />
            <p className="mt-2 text-[12px] font-bold text-[#646b6a]">ჯერ არაფერი არის დამატებული</p>
            <p className="mt-1 text-[11px] leading-relaxed text-[#969a96]">აირჩიე მექანიზმები კომპლექტის ასაწყობად.</p>
          </div>
        ) : (
          <div className="space-y-2">
            {result.selected.map((ერთეული) => (
              <div key={ერთეული.id} data-testid={`selected-mechanism-${ერთეული.id}`} className="rounded-lg border border-[#e1ddd6] bg-[#fbfaf7] p-2.5">
                <div className="flex ერთეულიs-start gap-2">
                  <span className="mt-0.5 flex h-6 min-w-6 ერთეულიs-center justify-center rounded bg-[#ece9e2] px-1 mono text-[10px] font-medium text-[#626967]">{ერთეული.width}M</span>
                  <div className="min-w-0 flex-1">
                    <div className="truncate text-[12px] font-extrabold text-[#394042]">{ერთეული.name}</div>
                    <div className="mono mt-0.5 truncate text-[9px] text-[#909490]">{ერთეული.article}</div>
                  </div>
                  <button type="button" data-testid={`button-remove-${ერთეული.id}`} onClick={() => onRemove(ერთეული.id)} className="focus-ring rounded p-1 text-[#a4a7a2] hover:bg-[#f2e7e2] hover:text-[#ff0000]">
                    <X size={14} />
                  </button>
                </div>
                <div className="mt-2 flex ერთეულიs-center justify-between">
                  <span className="text-[10px] text-[#848985]">{ერთეული.variant}</span>
                  <div className="flex ერთეულიs-center overflow-hidden rounded-md border border-[#dcd8d0] bg-[#f5f3ee]">
                    <button type="button" data-testid={`button-decrement-${ერთეული.id}`} onClick={() => onDecrement(ერთეული.id)} aria-label={`Decrease ${ერთეული.name}`} className="focus-ring flex h-7 w-7 ერთეულიs-center justify-center text-[#5f6665] hover:bg-[#ebe8e1]"><Minus size={12} /></button>
                    <span data-testid={`quantity-${ერთეული.id}`} className="mono w-6 text-center text-[11px] font-medium text-[#303739]">{ერთეული.quantity}</span>
                    <button type="button" data-testid={`button-increment-${ერთეული.id}`} onClick={() => onIncrement(ერთეული.id)} aria-label={`Increase ${ერთეული.name}`} className="focus-ring flex h-7 w-7 ერთეულიs-center justify-center text-[#5f6665] hover:bg-[#ebe8e1]"><Plus size={12} /></button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
        <div className={`mt-4 flex ერთეულიs-center gap-2 rounded-lg px-3 py-2.5 ${result.isValid ? 'bg-[#eaf4ed] text-[#327554]' : 'bg-[#fbebe6] text-[#b2382c]'}`}>
          {result.isValid ? <Check size={15} strokeWidth={2.7} /> : <AlertTriangle size={15} />}
          <span data-testid="status-configuration" className="text-[11px] font-bold">
            {result.isValid ? 'Configuration is physically valid' : 'Configuration needs attention'}
          </span>
        </div>
        {!result.isValid && (
          <div data-testid="error-configuration" className="mt-2 space-y-1 rounded-lg border border-[#efc8be] bg-[#fff8f5] px-3 py-2.5">
            {result.errors.map((error) => <p key={error} className="text-[11px] leading-relaxed text-[#a33d32]">{error}</p>)}
          </div>
        )}
      </div>
    </aside>
  );
}

function MechanismCard({ ერთეული, selected, onAdd }: { ერთეული: Mechanism; selected?: SelectedMechanism; onAdd: (ერთეული: Mechanism) => void }) {
  return (
    <div className="group flex min-h-[130px] flex-col justify-between rounded-[11px] border border-[#dedbd4] bg-[#fdfcf9] p-3.5 transition-all hover:border-[#bdbbb4] hover:shadow-[0_5px_18px_rgba(45,48,49,.06)]">
      <div>
        <div className="flex ერთეულიs-start justify-between gap-2">
          <span className="rounded bg-[#ece9e2] px-1.5 py-1 mono text-[9px] font-medium text-[#707673]">{ერთეული.width}M</span>
          {selected && <span className="flex ერთეულიs-center gap-1 rounded-full bg-[#f7e4df] px-1.5 py-1 text-[9px] font-bold text-[#be372c]"><Check size={10} /> {selected.quantity} in kit</span>}
        </div>
        <h3 className="mt-2 text-[13px] font-extrabold tracking-[-.02em] text-[#343b3d]">{ერთეული.name}</h3>
        <p className="mt-1 text-[10px] text-[#797f7d]">{ერთეული.detail}</p>
      </div>
      <div className="mt-3 flex ერთეულიs-end justify-between gap-2">
        <div>
          <div className="mono text-[10px] text-[#666d6b]">{ერთეული.variant}</div>
          <div className="mono mt-1 text-[9px] text-[#a0a39e]">{ერთეული.article}</div>
        </div>
        <button type="button" data-testid={`button-add-${ერთეული.id}`} onClick={() => onAdd(ერთეული)} className="focus-ring flex h-9 w-9 shrink-0 ერთეულიs-center justify-center rounded-lg bg-[#31383a] text-[#fcfaf4] transition-colors hover:bg-[#ff0000] active:scale-95" aria-label={`Add ${ერთეული.name}`}>
          <Plus size={17} strokeWidth={2.4} />
        </button>
      </div>
    </div>
  );
}

function BomSection({ layout, finish, result }: { layout: LayoutId; finish: Finish; result: ReturnType<typeof calculateConfiguration> }) {
  const accessories = accessoryBom(layout, finish);
  return (
    <section className="panel overflow-hidden">
      <div className="panel-header flex ერთეულიs-center justify-between px-4 py-4 sm:px-5">
        <div>
          <div className="eyebrow">შედეგი / კომპლექტაცია</div>
          <h2 className="mt-1 text-[18px] font-extrabold tracking-[-.035em] text-[#292f31]">კომპლექტის კომპონენტები</h2>
        </div>
        <div className="flex h-9 w-9 ერთეულიs-center justify-center rounded-lg bg-[#f3e6df] text-[#ff0000]"><Zap size={16} /></div>
      </div>
      <div className="divide-y divide-[#ebe7e0]">
        {[...result.selected.map((ერთეული) => ({ article: ერთეული.article, name: ერთეული.name, variant: ერთეული.variant, kind: 'Mechanism', quantity: ერთეული.quantity })), ...accessories.map((ერთეული) => ({ ...ერთეული, quantity: 1 }))].map((ერთეული, index) => (
          <div key={`${ერთეული.article}-${index}`} data-testid={`bom-row-${index}`} className="grid grid-cols-[1fr_auto] gap-3 px-4 py-3.5 sm:grid-cols-[88px_1fr_90px_42px] sm:ერთეულიs-center sm:px-5">
            <span className={`hidden w-fit rounded px-1.5 py-1 text-[9px] font-bold uppercase tracking-[.08em] sm:block ${ერთეული.kind === 'Automatic' ? 'bg-[#f1eee7] text-[#7d827e]' : 'bg-[#f7e4df] text-[#bd3a2e]'}`}>{ერთეული.kind}</span>
            <div className="min-w-0">
              <div className="truncate text-[12px] font-extrabold text-[#3d4445]">{ერთეული.name}</div>
              <div className="mono mt-1 text-[9px] text-[#8f9490]">{ერთეული.article} · {ერთეული.variant}</div>
            </div>
            <span className="mono text-right text-[11px] text-[#5e6664]">× {ერთეული.quantity}</span>
            <span className="hidden text-right text-[10px] text-[#999e98] sm:block">—</span>
          </div>
        ))}
      </div>
      <div className="border-t border-[#e4e0d8] bg-[#f5f3ee] px-4 py-3 text-[10px] leading-relaxed text-[#818682] sm:px-5">
        Mounting plate and frame are added automatically from the selected layout and finish. Always confirm the live product data before ordering.
      </div>
    </section>
  );
}

function Home() {
  const [finish, setFinish] = useState<Finish>('AN');
  const [layout, setLayout] = useState<LayoutId>('2+2M');
  const [selected, setSelected] = useState<SelectedMechanism[]>([]);
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<MechanismCategory>('All');
  const [notice, setNotice] = useState('');
  const [catalogStatus, setCatalogStatus] = useState<'loading' | 'validated'>('loading');
  const [catalogVersion, setCatalogVersion] = useState(0);

  useEffect(() => {
    const timer = window.setTimeout(() => setCatalogStatus('validated'), 640);
    return () => window.clearTimeout(timer);
  }, []);

  const result = useMemo(() => calculateConfiguration(layout, finish, selected), [layout, finish, selected]);
  const health = useMemo(() => catalogHealth(), [catalogVersion]);
  const mechanisms = useMemo(() => getMechanisms(), [catalogVersion]);
  const categoryLabels = useMemo(() => getCategoryLabels(), [catalogVersion]);
  const filteredMechanisms = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return mechanisms.filter((ერთეული) => {
      const matchesCategory = category === 'All' || ერთეული.category === category;
      const matchesFinish = ერთეული.product.color === finish || ერთეული.product.color === 'NEUTRAL';
      const matchesQuery = !needle || [ერთეული.article, ერთეული.abbCode, ერთეული.name, ერთეული.variant, ერთეული.detail].join(' ').toLowerCase().includes(needle);
      return matchesCategory && matchesFinish && matchesQuery;
    });
  }, [category, finish, mechanisms, query]);

  const updateSelected = (id: string, updater: (ერთეული: SelectedMechanism) => SelectedMechanism | null) => {
    setSelected((current) => current.flatMap((ერთეული) => ერთეული.id === id ? (updater(ერთეული) ? [updater(ერთეული)!] : []) : [ერთეული]));
  };
  const addMechanism = (ერთეული: Mechanism) => {
    const next = selected.some((selectedItem) => selectedItem.id === ერთეული.id)
      ? selected.map((selectedItem) => selectedItem.id === ერთეული.id ? { ...selectedItem, quantity: selectedItem.quantity + 1 } : selectedItem)
      : [...selected, { ...ერთეული, quantity: 1 }];
    const nextResult = calculateConfiguration(layout, finish, next);
    if (!nextResult.isValid) {
      setNotice(`${ერთეული.name} will not fit in the available zones for ${layout}.`);
      window.setTimeout(() => setNotice(''), 3200);
      return;
    }
    setSelected(next);
    setNotice(`${ერთეული.name} added to the kit.`);
    window.setTimeout(() => setNotice(''), 2200);
  };
  const removeMechanism = (id: string) => updateSelected(id, () => null);
  const decrement = (id: string) => updateSelected(id, (ერთეული) => ერთეული.quantity > 1 ? { ...ერთეული, quantity: ერთეული.quantity - 1 } : null);
  const increment = (id: string) => {
    const ერთეული = selected.find((selectedItem) => selectedItem.id === id);
    if (ერთეული) addMechanism(ერთეული);
  };
  const reset = () => {
    setFinish('AN');
    setLayout('2+2M');
    setSelected([]);
    setQuery('');
    setCategory('All');
    setNotice('Configuration reset.');
    window.setTimeout(() => setNotice(''), 2200);
  };
  const importCatalog = async (file: File) => {
    try {
      const products = await parseCatalogFile(file);
      setProductCatalog(products);
      setSelected([]);
      setCatalogVersion((version) => version + 1);
      setCatalogStatus('validated');
      setNotice(`იმპორტიed ${products.length} catalogue records.`);
    } catch (error) {
      setNotice(error instanceof Error ? error.message : 'Catalogue could not be imported.');
    }
    window.setTimeout(() => setNotice(''), 3600);
  };

  return (
    <div className="app-shell">
       <AppHeader status={catalogStatus} onგასუფთავება={reset} onიმპორტი={importCatalog} />
      <main className="mx-auto max-w-[1440px] px-4 pb-12 pt-5 sm:px-6 sm:pt-7 lg:px-10">
        <div className="mb-5 flex flex-col justify-between gap-3 sm:mb-7 sm:flex-row sm:ერთეულიs-end">
          <div>
            <div className="eyebrow flex ერთეულიs-center gap-2"><span className="h-1.5 w-1.5 rounded-full bg-[#ff0000]" /> ფიზიკური კომპლექტის აწყობა</div>
            <h1 className="mt-2 max-w-[680px] text-[28px] font-extrabold leading-[1.06] tracking-[-.055em] text-[#272d30] sm:text-[34px]">ააწყვე სწორი კომპლექტი,<br className="hidden sm:block" />მოდულ-მოდულად.</h1>
            <p className="mt-2 max-w-[620px] text-[13px] leading-relaxed text-[#727977]">აირჩიე ფერი და განლაგება, შემდეგ განათავსე მექანიზმები რეალურ ფიზიკურ ზონებში. კომპლექტაცია ავტომატურად განახლდება.</p>
          </div>
          <div className="flex ერთეულიs-center gap-2 self-start rounded-lg border border-[#ddd9d2] bg-[#fdfcf9] px-3 py-2 sm:self-auto">
            <Database size={14} className={catalogStatus === 'loading' ? 'text-[#c38d20]' : 'text-[#3d9468]'} />
            <div>
              <div className="mono text-[10px] font-medium text-[#555d5d]">{catalogStatus === 'loading' ? 'Verifying local data…' : `${health.records} records · ready`}</div>
              <div className="text-[9px] text-[#989c96]">წყარო: პროდუქტის მონაცემთა ბაზა</div>
            </div>
          </div>
        </div>

        <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_360px] xl:grid-cols-[minmax(0,1fr)_390px]">
          <div className="min-w-0 space-y-5">
            <section className="panel p-4 sm:p-5">
              <SectionHeading number="01—02" eyebrow="START HERE" title="Set your frame" action={<span className="hidden mono text-[10px] text-[#9a9d98] sm:block">ყველა არჩევანი აახლებს წინასწარ ხედს</span>} />
              <div className="mt-5 space-y-5">
                <FinishControl finish={finish} setFinish={setFinish} />
                <LayoutControl layout={layout} setLayout={setLayout} />
              </div>
            </section>

            <section className="panel overflow-hidden">
              <div className="panel-header px-4 py-4 sm:px-5">
                <SectionHeading number="03" eyebrow="MECHANISMS" title="Place functions" action={<span className="mono text-[10px] text-[#979b97]">{filteredMechanisms.length} shown</span>} />
                <div className="relative mt-4">
                  <Search size={15} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-[#8f9591]" />
                  <input
                    type="search"
                    value={query}
                    onChange={(event) => setQuery(event.target.value)}
                    data-testid="input-search-mechanisms"
                    placeholder="Search article, ABB code, name or variant"
                    className="focus-ring h-11 w-full rounded-lg border border-[#dcd8d0] bg-[#f8f7f3] pl-9 pr-9 text-[12px] text-[#333a3b] placeholder:text-[#a2a59f]"
                    aria-label="Search mechanisms"
                  />
                  {query && <button type="button" data-testid="button-clear-search" onClick={() => setQuery('')} className="focus-ring absolute right-2 top-1/2 -translate-y-1/2 rounded p-1.5 text-[#8f9591] hover:text-[#ff0000]" aria-label="Clear search"><X size={14} /></button>}
                </div>
                <div className="mt-3 flex gap-1.5 overflow-x-auto pb-1">
                   {(['All', ...categoryLabels] as MechanismCategory[]).map((ერთეული) => (
                    <button type="button" key={ერთეული} data-testid={`button-category-${ერთეული.toLowerCase()}`} onClick={() => setCategory(ერთეული)} className={`focus-ring min-h-9 shrink-0 rounded-full px-3 text-[11px] font-bold transition-colors ${category === ერთეული ? 'bg-[#31383a] text-[#fbfaf4]' : 'border border-[#dfdcd5] bg-[#fcfbf8] text-[#737a77] hover:bg-[#efede7]'}`} aria-pressed={category === ერთეული}>{ერთეული}</button>
                  ))}
                </div>
              </div>
              <div className="grid gap-2.5 p-4 sm:grid-cols-2 sm:p-5 xl:grid-cols-3">
                {filteredMechanisms.length === 0 ? (
                  <div data-testid="empty-mechanisms" className="col-span-full rounded-xl border border-dashed border-[#d6d2ca] bg-[#f7f7f7] px-5 py-10 text-center">
                    <Search size={20} className="mx-auto text-[#a0a39f]" />
                    <p className="mt-2 text-[13px] font-bold text-[#626967]">შესაბამისი მექანიზმი ვერ მოიძებნა</p>
                    <p className="mt-1 text-[11px] text-[#969b96]">სცადე არტიკულის ნომერი, ABB კოდი ან მოკლე საძიებო სიტყვა.</p>
                  </div>
                ) : filteredMechanisms.map((ერთეული) => <MechanismCard key={ერთეული.id} ერთეული={ერთეული} selected={selected.find((selectedItem) => selectedItem.id === ერთეული.id)} onAdd={addMechanism} />)}
              </div>
            </section>

            <section className="panel p-4 sm:p-5">
              <SectionHeading number="04" eyebrow="CHECK YOUR WORK" title="Physical placement" action={<span className="mono text-[10px] text-[#979b97]">{result.usedSlots} / {result.totalSlots} გამოყენებული მოდულები</span>} />
              <div className="mt-4">
                <ZoneDiagram layout={layout} finish={finish} placements={result.placements} />
              </div>
            </section>

            <BomSection layout={layout} finish={finish} result={result} />
          </div>

          <div className="lg:pt-0">
            <Summary layout={layout} finish={finish} result={result} onRemove={removeMechanism} onIncrement={increment} onDecrement={decrement} />
          </div>
        </div>

        {notice && (
          <div data-testid="toast-configuration" className="fade-up fixed bottom-4 left-1/2 z-50 flex max-w-[calc(100vw-32px)] -translate-x-1/2 ერთეულიs-center gap-2 rounded-lg border border-[#474d4e] bg-[#303738] px-4 py-3 text-[12px] font-bold text-[#fbfaf4] shadow-xl">
            {notice.includes('will not') ? <AlertTriangle size={15} className="text-[#f3ba4b]" /> : <Check size={15} className="text-[#83cf9d]" />}
            <span>{notice}</span>
          </div>
        )}

        {DEBUG && (
          <section data-testid="debug-panel" className="mt-5 rounded-xl border border-dashed border-[#c9c5bc] bg-[#ebe9e3] p-4">
            <div className="eyebrow">DEBUG MODE · ?debug=true</div>
            <pre className="mono mt-3 max-h-72 overflow-auto whitespace-pre-wrap break-all text-[10px] leading-relaxed text-[#5e6665]">{JSON.stringify({ finish, layout, selected, placements: result.placements, errors: result.errors, catalog: health }, null, 2)}</pre>
          </section>
        )}
      </main>
      <footer className="border-t border-[#ddd9d1] px-4 py-5 text-center sm:px-6">
        <p className="mono text-[10px] text-[#999d98]">ABB Zenit configurator · local calculation only · confirm final article data before order</p>
      </footer>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <ErrorBoundary>
          <Home />
        </ErrorBoundary>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;