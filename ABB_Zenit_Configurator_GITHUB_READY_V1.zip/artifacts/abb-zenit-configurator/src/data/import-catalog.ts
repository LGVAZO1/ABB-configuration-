import type { Product } from './types';

const requiredKeys = ['article', 'name', 'color', 'type', 'variant', 'width', 'functions'];

function normalizeRecord(record: Record<string, unknown>): Product {
  const normalized = Object.fromEntries(
    Object.entries(record).map(([key, value]) => [key.trim(), typeof value === 'string' ? value.trim() : value]),
  );
  const missing = requiredKeys.filter((key) => normalized[key] === undefined || normalized[key] === '');
  if (missing.length) throw new Error(`Missing required field(s): ${missing.join(', ')}.`);

  return {
    article: String(normalized.article),
    abbCode: normalized.abbCode ? String(normalized.abbCode) : '',
    name: String(normalized.name),
    color: String(normalized.color).toUpperCase() as Product['color'],
    type: String(normalized.type),
    variant: String(normalized.variant),
    width: Number(normalized.width),
    functions: Number(normalized.functions),
    layout: normalized.layout ? String(normalized.layout) : undefined,
    notes: normalized.notes ? String(normalized.notes) : undefined,
    useInZenitWallConfigurator:
      normalized.useInZenitWallConfigurator === undefined
        ? true
        : normalized.useInZenitWallConfigurator === true ||
          String(normalized.useInZenitWallConfigurator).toLowerCase() === 'true',
  };
}

function parseCsv(text: string): Record<string, unknown>[] {
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = '';
  let quoted = false;
  for (let index = 0; index < text.length; index += 1) {
    const character = text[index];
    const next = text[index + 1];
    if (character === '"' && quoted && next === '"') {
      cell += '"';
      index += 1;
    } else if (character === '"') {
      quoted = !quoted;
    } else if (character === ',' && !quoted) {
      row.push(cell);
      cell = '';
    } else if ((character === '\n' || character === '\r') && !quoted) {
      if (character === '\r' && next === '\n') index += 1;
      row.push(cell);
      if (row.some((item) => item.trim())) rows.push(row);
      row = [];
      cell = '';
    } else {
      cell += character;
    }
  }
  row.push(cell);
  if (row.some((item) => item.trim())) rows.push(row);
  if (rows.length < 2) throw new Error('CSV must include a header row and at least one product row.');
  const headers = rows[0].map((header) => header.trim());
  return rows.slice(1).map((values) =>
    Object.fromEntries(headers.map((header, index) => [header, values[index] ?? ''])),
  );
}

export async function parseCatalogFile(file: File): Promise<Product[]> {
  const text = await file.text();
  const extension = file.name.toLowerCase().split('.').pop();
  if (extension === 'json') {
    const parsed = JSON.parse(text) as unknown;
    const rows = Array.isArray(parsed)
      ? parsed
      : typeof parsed === 'object' && parsed !== null && 'products' in parsed
        ? (parsed as { products: unknown[] }).products
        : null;
    if (!rows || !rows.every((row) => typeof row === 'object' && row !== null)) {
      throw new Error('JSON must contain an array of product records.');
    }
    return rows.map((row) => normalizeRecord(row as Record<string, unknown>));
  }
  if (extension === 'csv' || extension === 'txt') {
    return parseCsv(text).map(normalizeRecord);
  }
  throw new Error('Use a JSON or CSV catalogue export. Excel files should be converted to CSV first.');
}