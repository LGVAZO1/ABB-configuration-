import type { ConfiguratorMappings, LayoutDefinition } from './types';

export const layouts: LayoutDefinition[] = [
  { id: '2M', label: '2M', zones: [2] },
  { id: '3M', label: '3M', zones: [3] },
  { id: '2+2M', label: '2+2M', zones: [2, 2] },
  { id: '2+2+2M', label: '2+2+2M', zones: [2, 2, 2] },
  { id: '2+2+2+2M', label: '2+2+2+2M', zones: [2, 2, 2, 2] },
];

export const mappings: ConfiguratorMappings = {
  mountingPlates: {
    '2M': '1607/02/002',
    '3M': '1607/02/005',
    '2+2M': '1607/02/003',
    '2+2+2M': '1607/02/004',
    // 4 independent 2M zones use two 2+2M plates.
    '2+2+2+2M': '1607/02/003',
  },
  frames: {
    AN: {
      '2M': '1607/04/022',
      '3M': '1607/04/026',
      '2+2M': '1607/04/018',
      '2+2+2M': '1607/04/016',
      '2+2+2+2M': '1607/04/021',
    },
    BL: {
      '2M': '1607/03/022',
      '3M': '1607/03/027',
      '2+2M': '1607/03/018',
      '2+2+2M': '1607/03/016',
      '2+2+2+2M': '1607/03/021',
    },
  },
};

export const colorLabels = { AN: 'ანთრაციტი', BL: 'თეთრი' } as const;
export const typeLabels: Record<string, string> = {
  switch: 'ჩამრთველი', socket: 'როზეტი', communication: 'კომუნიკაცია',
  usb: 'USB დამტენი', dimmer: 'დიმერი', blank: 'საფარი', timer_relay: 'ტაიმერ-რელე',
};
