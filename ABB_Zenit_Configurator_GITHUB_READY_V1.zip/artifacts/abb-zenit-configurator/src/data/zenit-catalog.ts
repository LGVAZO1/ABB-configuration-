import productsJson from './products.json';
import { colorLabels, layouts as layoutDefinitions, mappings, typeLabels } from './mappings';
import type { LayoutId, Product, UserColor } from './types';

export type Finish = UserColor;
export type { LayoutId };

export type MechanismCategory = 'All' | string;

export type Mechanism = {
  id: string;
  article: string;
  abbCode: string;
  name: string;
  variant: string;
  category: string;
  width: number;
  detail: string;
  colorNote: string;
  product: Product;
};

export type Accessory = {
  article: string;
  name: string;
  variant: string;
};

export const PRODUCTS: Product[] = [...(productsJson as Product[])];

export const FINISHES: Array<{
  id: Finish;
  label: string;
  longLabel: string;
  swatch: string;
  ink: string;
}> = [
  { id: 'AN', label: 'AN', longLabel: colorLabels.AN, swatch: '#353a3e', ink: '#f6f4ef' },
  { id: 'BL', label: 'BL', longLabel: colorLabels.BL, swatch: '#f2f0ea', ink: '#252a2d' },
];

export const LAYOUTS = layoutDefinitions.map((layout) => ({
  id: layout.id,
  label: layout.label,
  zones: layout.zones,
  caption: layout.zones.length === 1 ? 'single zone' : `${layout.zones.length} zones`,
}));

export function setProductCatalog(products: Product[]): void {
  PRODUCTS.splice(0, PRODUCTS.length, ...products);
}

export function getMechanisms(): Mechanism[] {
  return PRODUCTS.filter((product) => product.useInZenitWallConfigurator && product.isMechanism && product.componentRole === 'mechanism').map((product) => ({
    id: product.article,
    article: product.article,
    abbCode: product.abbCode,
    name: product.name,
    variant: product.variant,
    category: typeLabels[product.type] ?? product.type,
    width: product.width,
    detail: product.notes ?? `${product.functions} ${product.functions === 1 ? 'function' : 'functions'}`,
    colorNote: product.color === 'NEUTRAL' ? 'Technical component' : product.color,
    product,
  }));
}

export function getCategoryLabels(): string[] {
  return [...new Set(getMechanisms().map((item) => item.category))];
}

export const ACCESSORIES: Record<'plate' | 'frame', Record<LayoutId, Accessory>> = {
  plate: Object.fromEntries(
    LAYOUTS.map((layout) => {
      const article = mappings.mountingPlates[layout.id];
      const product = PRODUCTS.find((item) => item.article === article);
      return [
        layout.id,
        {
          article: article ?? 'not-configured',
          name: product?.name ?? 'Mounting plate mapping not configured',
          variant: layout.id,
        },
      ];
    }),
  ) as Record<LayoutId, Accessory>,
  frame: Object.fromEntries(
    LAYOUTS.map((layout) => {
      const article = mappings.frames.AN[layout.id];
      const product = PRODUCTS.find((item) => item.article === article);
      return [
        layout.id,
        {
          article: article ?? 'not-configured',
          name: product?.name ?? 'Frame mapping not configured',
          variant: layout.id,
        },
      ];
    }),
  ) as Record<LayoutId, Accessory>,
};