export type ProductColor = 'AN' | 'BL' | 'NEUTRAL';
export type UserColor = Exclude<ProductColor, 'NEUTRAL'>;
export type LayoutId = '2M' | '3M' | '2+2M' | '2+2+2M' | '2+2+2+2M';

export interface Product {
  article: string;
  abbCode: string;
  name: string;
  color: ProductColor;
  type: string;
  variant: string;
  width: number;
  functions: number;
  layout?: string;
  notes?: string;
  useInZenitWallConfigurator: boolean;
  layoutPattern?: string;
  componentRole?: string;
  isMechanism?: boolean;
  isFrame?: boolean;
  isMountingPlate?: boolean;
  isFiller?: boolean;
  isDIN?: boolean;
  requiresFrame?: boolean;
  requiresMountingPlate?: boolean;
  verificationStatus?: string;
  abbFamilyCode?: string;
}

export interface LayoutDefinition {
  id: LayoutId;
  label: string;
  zones: number[];
}

export interface ConfiguratorMappings {
  mountingPlates: Partial<Record<LayoutId, string>>;
  frames: Record<UserColor, Partial<Record<LayoutId, string>>>;
}

export interface SelectedProduct {
  product: Product;
  quantity: number;
}

export interface PlacementZone {
  id: number;
  capacity: number;
  used: number;
  remaining: number;
  products: Product[];
}

export interface KitItem {
  article: string;
  name: string;
  abbCode: string;
  quantity: number;
  role: 'mechanism' | 'mounting_plate' | 'frame' | 'accessory' | 'filler';
  physicalWidth: number;
}

export interface ValidationReport {
  valid: boolean;
  errors: string[];
  warnings: string[];
}

export interface BuildSuccess {
  success: true;
  color: UserColor;
  layout: LayoutId;
  zones: PlacementZone[];
  kit: KitItem[];
  warnings: string[];
}

export interface BuildFailure {
  success: false;
  color: UserColor;
  layout: LayoutId;
  zones: PlacementZone[];
  kit: KitItem[];
  warnings: string[];
  errorCode:
    | 'NO_PRODUCT_SELECTED'
    | 'PRODUCT_NOT_FOUND'
    | 'COLOR_MISMATCH'
    | 'PRODUCT_NOT_ENABLED'
    | 'INVALID_PRODUCT_DATA'
    | 'NO_VALID_PLACEMENT'
    | 'MOUNTING_PLATE_MAPPING_MISSING'
    | 'FRAME_MAPPING_MISSING';
  message: string;
}

export type BuildResult = BuildSuccess | BuildFailure;