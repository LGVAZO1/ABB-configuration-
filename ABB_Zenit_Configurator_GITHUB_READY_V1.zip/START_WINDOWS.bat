@echo off
setlocal
cd /d "%~dp0"

echo ===============================================
echo ABB Zenit Configurator - Windows Launcher
echo ===============================================

echo.
where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js is not installed or not in PATH.
  pause
  exit /b 1
)

where pnpm.cmd >nul 2>nul
if errorlevel 1 (
  echo ERROR: pnpm is not installed or not in PATH.
  echo Install pnpm, then run this file again.
  pause
  exit /b 1
)

if not exist node_modules\ (
  echo Installing dependencies for Windows...
  call pnpm.cmd install
  if errorlevel 1 (
    echo.
    echo Dependency installation failed.
    pause
    exit /b 1
  )
)

set PORT=5173
set BASE_PATH=/

echo.
echo Starting ABB Zenit Configurator...
echo Open http://localhost:5173 in your browser.
echo Press Ctrl+C to stop the server.
echo.
call pnpm.cmd --filter @workspace/abb-zenit-configurator run dev

endlocal
