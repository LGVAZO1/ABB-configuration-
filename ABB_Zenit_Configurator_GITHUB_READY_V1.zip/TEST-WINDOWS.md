# ABB Zenit Configurator — Windows test

This package keeps the original configurator architecture and applies only the agreed Zenit logic/data corrections. Windows-specific dependency exclusions were removed for the native x64 packages required by Vite/Tailwind/Rollup.

## Start

1. Extract this ZIP to a normal folder, e.g. `C:\Users\Administrator\Desktop\abb1`.
2. Open `START_WINDOWS.bat`.
3. The launcher uses `pnpm.cmd`, so PowerShell Execution Policy does not matter.
4. If dependencies are not installed, the launcher runs `pnpm install` automatically.
5. Open `http://localhost:5173/`.

Manual commands, if preferred:

```powershell
cd C:\Users\Administrator\Desktop\abb1
pnpm.cmd install
pnpm.cmd --filter @workspace/abb-zenit-configurator run dev
```

## Logic included

- 2M / 3M / 2+2M / 2+2+2M / 2+2+2+2M layouts
- 1M+1M can share one 2M zone
- 2M mechanism occupies a complete 2M zone
- 3M mechanism cannot be placed in a 2M zone
- 4-zone layout uses two 2+2M mounting plates
- Frame and mounting plate are separate BOM items
- RJ45 `1607/02/001` automatically gets the matching AN/BL cover
- 2M data/internet covers are accessories, not mechanisms
- 1M blank cover is a filler, not a frame
- DIN timer relay is excluded from the wall Zenit configurator
- missing mappings do not invent article numbers
- color changes map to real SKUs
- ABB code/layout conflicts from the master data are preserved as unresolved where confirmation is still required

## Database

`database/ABB_Zenit_Database_FINAL_MASTER_v1.0.xlsx`

The runtime product data is the corrected export used by the configurator. The Excel database is included as the editable source of truth for subsequent corrections.
